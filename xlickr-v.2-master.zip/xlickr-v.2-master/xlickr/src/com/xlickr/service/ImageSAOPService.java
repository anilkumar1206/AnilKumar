package com.xlickr.service;

import java.util.List;

public interface ImageSAOPService {

	public List<com.vamsee.flickr.ejb.FlickrImage> getFlickrImages();
}
