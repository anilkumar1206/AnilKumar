package com.xlickr.dao;

import java.util.List;


public interface ImageSOAPDAO {

	public List<com.vamsee.flickr.ejb.FlickrImage> getFlickrImages();
	
	
}
